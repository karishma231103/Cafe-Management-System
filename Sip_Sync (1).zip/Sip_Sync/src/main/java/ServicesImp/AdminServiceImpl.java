package ServicesImp;

import java.util.List;
import Dao.*;
import DaoImp.*;
import Entity.*;
import Services.AdminService;

public class AdminServiceImpl implements AdminService {

	AdminDao adminDao=new AdminDaoImp();
	@Override
	public Admin createAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminDao.createAdmin(admin);
	}

	@Override
	public Admin getAdminById(Long admin_id) {
		// TODO Auto-generated method stub
		return adminDao.getAdmin(admin_id);
	}

	@Override
	public List<Admin> getAllAdmins() {
		// TODO Auto-generated method stub
		return adminDao.getAllAdmins();
	}

}
