package ServicesImp;
import DaoImp.*;
import Entity.Order;

import java.util.List;

import Dao.*;
import Services.OrderServices;

public class OrderServiceImp implements OrderServices{
	
	OrderDao orderDao=new OrderDaoImp();

	@Override
	public Order createOrder(Order order) {
		// TODO Auto-generated method stub
		return orderDao.createOrder(order);
	}

	@Override
	public List getOrder() {
		// TODO Auto-generated method stub
		return orderDao.getOrder();
	}

	@Override
	public Order deleteOrder(Long order_id) {
		// TODO Auto-generated method stub
		return orderDao.deleteOrder(order_id);
	}
}
