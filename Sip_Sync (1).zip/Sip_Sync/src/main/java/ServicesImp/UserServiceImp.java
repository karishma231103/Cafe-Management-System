package ServicesImp;

import Services.UserServices;
import java.util.List;
import Dao.*;
import DaoImp.UserDaoImp;
import Entity.User;


public class UserServiceImp implements UserServices{
	
	UserDao userdao=new UserDaoImp();

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		return userdao.createUser(user);
	}

	
	@Override
	public User getUserById(Long user_id) {
		// TODO Auto-generated method stub
		return userdao.getUserById(user_id);
	}

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userdao.getAllUsers();
	}

	@Override
	public User updateUser(User userToUpdate) {
		// TODO Auto-generated method stub
		return userdao.updateUser(userToUpdate);
	}

	@Override
	public String deleteUser(Long user_id) {
		// TODO Auto-generated method stub
		return userdao.deleteUser(user_id);
	}
}
