package ServicesImp;
import java.util.List;
import DaoImp.*;
import Entity.Employee;
import Dao.*;
import Services.EmployeeServices;

public class EmployeeServiceImpl implements EmployeeServices{

	EmployeeDao employeeDao = new EmployeeDaoImp();

	@Override
	public Employee createEmployee(Employee emp) {

		return employeeDao.createEmployee(emp);
	}

	@Override
	public Employee getEmployeeByID(Long emp_id) {
		// TODO Auto-generated method stub
		return employeeDao.getEmployeeByID(emp_id);
	}

	@Override
	public Employee deleteEmployee(Long emp_id) {
		// TODO Auto-generated method stub
		return employeeDao.deleteEmployee(emp_id);
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeDao.getAllEmployees();
	}

	@Override
	public Employee updateEmployee(Employee employeeToUpdate) {
		// TODO Auto-generated method stub
		return employeeDao.updateEmployee(employeeToUpdate);
	}
}
