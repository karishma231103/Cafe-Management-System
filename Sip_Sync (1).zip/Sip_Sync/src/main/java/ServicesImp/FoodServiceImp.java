package ServicesImp;
import java.util.List;
import Dao.FoodDao;
import DaoImp.FoodDaoImp;
import Entity.Food;
import Services.*;

public class FoodServiceImp implements FoodServices {

    FoodDao foodDao = new FoodDaoImp();
	@Override
	public Food createFood(Food food) 
	{
		return foodDao.createFood(food);
	}
	
	@Override
	public Food updateFood(Food foodToUpdate) {
		// TODO Auto-generated method stub
		return foodDao.updateFood(foodToUpdate);
	}
	@Override
	public Food deleteFood(Long food_id) {
		// TODO Auto-generated method stub
		return foodDao.deleteFood(food_id);
	}
	@Override
	public Food getFoodById(Long food_id) {
		// TODO Auto-generated method stub
		return foodDao.getFoodById(food_id);
	}
	@Override
	public List<Food> getAllFoods() {
		// TODO Auto-generated method stub
		return foodDao.getAllFoods();
	}

}
