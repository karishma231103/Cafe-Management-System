package com.demo.Sip_Sync;

import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("!!Welcome To SipSync!!");
        mainOperations();
    }

    static void mainOperations() {
        while (true) {
            System.out.println("Press 1. Admin Details\n"
                    + "Press 2. Employee Details\n"
                    + "Press 3. User Details\n"
                    + "Press 4. Food Details\n"
                    + "Press 5. Order Details\n"
                    + "Press 6. Quit");

            int input = sc.nextInt();

            switch (input) {
                case 1:
                    AllOperations.AdminOperations();
                    System.out.println("---------------------------------------");
                    break;

                case 2:
                    AllOperations.EmployeeOperations();
                    System.out.println("---------------------------------------");
                    break;

                case 3:
                    AllOperations.UserOperations();
                    System.out.println("---------------------------------------");
                    break;

                case 4:
                    AllOperations.FoodOperations();
                    System.out.println("---------------------------------------");
                    break;

                case 5:
                    AllOperations.OrderOperations();
                    System.out.println("---------------------------------------");
                    break;

                case 6:
                    System.exit(0);
                    break;

                default:
                    System.out.println("Wrong input");
            }
        }
    }
}
