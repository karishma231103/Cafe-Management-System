package com.demo.Sip_Sync;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import Entity.Admin;
import Entity.Employee;
import Entity.Food;
import Entity.Order;
import Entity.User;
import Services.*;
import ServicesImp.*;

public class AllOperations {

	private static AdminService adminService = new AdminServiceImpl();
	private static EmployeeServices empService = new EmployeeServiceImpl();
	private static UserServices userService = new UserServiceImp();
	private static FoodServices foodService = new FoodServiceImp();
	private static OrderServices orderService = new OrderServiceImp();

	static Scanner sc = new Scanner(System.in);

	// Input methods
	public static Admin AdminInputs() {
		sc.nextLine();
		
		System.out.println("Enter Admin Name");
		String name = sc.nextLine();

		System.out.println("Enter Admin Password");
		String password = sc.nextLine();

		System.out.println("Enter Email");
		String email = sc.nextLine();

		System.out.println("Enter Phone No");
		String phone_no = sc.nextLine();

		return new Admin( name, password, email, phone_no);
	}

	public static Employee EmployeeInputs() {
		sc.nextLine();
		
		System.out.println("Enter Employee Name");
		String emp_name = sc.nextLine();

		System.out.println("Enter Employee Position");
		String emp_position = sc.nextLine();

		System.out.println("Enter Employee Salary");
		String salary = sc.nextLine();
		return new Employee( emp_name, emp_position, salary);
	}

	public static User UserInputs() {
		sc.nextLine();
		
		System.out.println("Enter User Name");
		String name = sc.nextLine();

		System.out.println("Enter Phone No");
		String phone_no = sc.nextLine();

		System.out.println("Enter User Password");
		String password = sc.nextLine();

		return new User( name, phone_no, password);
	}

	public static Food FoodInputs() {
		sc.nextLine();
		System.out.println("Enter Food ID");
		String food_id = sc.nextLine();

		System.out.println("Enter Food Name");
		String name = sc.nextLine();

		System.out.println("Enter Food Price");
		String price = sc.nextLine();

		System.out.println("Availability");
		String availability = sc.nextLine();
		return new Food( name, price, availability);
	}

	public static Order OrderInputs() {
		sc.nextLine();

		System.out.println("Total Amount");
		String total_amount = sc.nextLine();

		LocalDate order_date = LocalDate.now();

		User user = UserInputs();
		return new Order(total_amount, order_date,user);
	}

	// Admin operations
	public static void AdminOperations() {
		while (true) {
			System.out.println("Press 1.Add Admin\n"
					+ "Press 2 to Retrieve Admin by ID\n"
					+ "Press 3.Retrieve All Admins\n"
					+ "Press 4.To get back to the main menu");
			int input = sc.nextInt();

			switch (input) {
			case 1:
				Admin admin = AdminInputs();
				Admin savedAdmin = adminService.createAdmin(admin);
				System.out.println("Admin added successfully: " + savedAdmin);
				break;

			case 2:
				System.out.println("Enter Admin ID to retrieve:");
				Long adminIdToRetrieve = sc.nextLong();
				Admin retrievedAdmin = adminService.getAdminById(adminIdToRetrieve);
				if (retrievedAdmin != null) {
					System.out.println("Admin retrieved successfully: " + retrievedAdmin);
				} else {
					System.out.println("No Admin found with ID: " + adminIdToRetrieve);
				}
				break;
			case 3:
				List<Admin> admins = adminService.getAllAdmins();
				for (Admin a : admins) {
					System.out.println(a);
				}
				break;

			case 5:
				Main.mainOperations();
				break;

			default:
				System.out.println("Invalid input. Please try again.");
			}
		}
	}
	// Employee operations
	public static void EmployeeOperations() {
		while (true) {
			System.out.println("Press 1 to Add Employee\n"
					+ "Press 2 to Retrieve Employees By ID"
					+ "Press 3 to Retrieve All Employees\n"
					+ "Press 4 to Update Employee\n"
					+ "Press 5 to Delete Employee\n"
					+ "Press 6 to Go Back to Main Menu");

			int input = sc.nextInt();

			switch (input) {
			case 1:
				Employee employee = EmployeeInputs();
				Employee savedEmployee = empService.createEmployee(employee);
				System.out.println("Employee added successfully: " + savedEmployee);
				break;

			case 2:
				System.out.println("Enter Employee ID to retrieve:");
				Long empIdToRetrieve = sc.nextLong();
				Employee retrievedEmployee = empService.getEmployeeByID(empIdToRetrieve);
				if (retrievedEmployee != null) {
					System.out.println("Employee details: " + retrievedEmployee);
				} else {
					System.out.println("Employee not found with ID: " + empIdToRetrieve);
				}
				break;

			case 3:
				List<Employee> employees = empService.getAllEmployees();
				for (Employee e : employees) {
					System.out.println(e);
				}
				break;

			case 4:
			    System.out.println("Enter Employee ID to update:");
			    Long empIdToUpdate = sc.nextLong();
			    Employee employeeToUpdate = EmployeeInputs();
			    employeeToUpdate.setEmp_Id(empIdToUpdate);
			    Employee updatedEmployee = empService.updateEmployee(employeeToUpdate);
			    System.out.println("Employee updated successfully: " + updatedEmployee);
			    break;

			case 5:
			    System.out.println("Enter Employee ID to delete:");
			    Long empIdToDelete = sc.nextLong(); // Change to nextLong() if empId is Long
			    empService.deleteEmployee(empIdToDelete); // Update method signature to accept Long
			    System.out.println("Employee deleted successfully.");
			    break;


			case 6:
				Main.mainOperations();
				break;

			default:
				System.out.println("Invalid input. Please try again.");
			}
		}
	}

	// User operations
	public static void UserOperations() {
		while (true) {
			System.out.println("Press 1 to Add User\n"
					+ "Press 2 to Retrieve User By ID\n"
					+ "Press 2 to Retrieve All Users\n"
					+ "Press 3 to Update User\n"
					+ "Press 4 to Delete User\n"
					+ "Press 5 to Go Back to Main Menu");

			int input = sc.nextInt();

			switch (input) {
			case 1:
				User user = UserInputs();
				User savedUser = userService.createUser(user);
				System.out.println("User added successfully: " + savedUser);
				break;

			case 2:
				System.out.println("Enter User ID to retrieve:");
				Long userIdToRetrieve = sc.nextLong();
				User retrievedUser = userService.getUserById(userIdToRetrieve);
				if (retrievedUser != null) {
					System.out.println("User details: " + retrievedUser);
				} else {
					System.out.println("User not found with ID: " + userIdToRetrieve);
				}
				break;

			case 3:
				List<User> users = userService.getAllUsers();
				for (User u : users) {
					System.out.println(u);
				}
				break;

			case 4:
				System.out.println("Enter User ID to update:");
				Long userIdToUpdate = sc.nextLong();
				User userToUpdate = UserInputs();
				userToUpdate.setUser_id(userIdToUpdate);
				User updatedUser = userService.updateUser(userToUpdate);
				System.out.println("User updated successfully: " + updatedUser);
				break;

			case 5:
				System.out.println("Enter User ID to delete:");
				Long userIdToDelete = sc.nextLong();
				userService.deleteUser(userIdToDelete);
				System.out.println("User deleted successfully.");
				break;

			case 6:
				Main.mainOperations();
				break;

			default:
				System.out.println("Invalid input. Please try again.");
			}
		}
	}

	// Food operations
	public static void FoodOperations() {
		while (true) {
			System.out.println("Press 1 to Add Food\n"
					+ "Press 2 to Retrieve All Foods\n"
					+ "Press 3 to Update Food\n"
					+ "Press 4 to Delete Food\n"
					+"Press 5 to Retrieve Food by ID\n"
					+ "Press 6 to Go Back to Main Menu");

			int input = sc.nextInt();

			switch (input) {
			case 1:
				Food food = FoodInputs();
				Food savedFood = foodService.createFood(food);
				System.out.println("Food added successfully: " + savedFood);
				break;

			case 2:
				List<Food> foods = foodService.getAllFoods();
				for (Food f : foods) {
					System.out.println(f);
				}
				break;

			case 3:
				System.out.println("Enter Food ID to update:");
				Long foodIdToUpdate = sc.nextLong();
				Food foodToUpdate = FoodInputs();
				foodToUpdate.setFood_id(foodIdToUpdate);
				Food updatedFood = foodService.updateFood(foodToUpdate);
				System.out.println("Food updated successfully: " + updatedFood);
				break;

			case 4:
				System.out.println("Enter Food ID to delete:");
				Long foodIdToDelete = sc.nextLong();
				foodService.deleteFood(foodIdToDelete);
				System.out.println("Food deleted successfully.");
				break;

			case 5:
				System.out.println("Enter Food ID to retrieve:");
				Long foodIdToRetrieve = sc.nextLong();
				Food retrievedFood = foodService.getFoodById(foodIdToRetrieve);
				if (retrievedFood != null) {
					System.out.println("Food retrieved successfully: " + retrievedFood);
				} else {
					System.out.println("No Food found with ID: " + foodIdToRetrieve);
				}
				break;

			case 6:
				Main.mainOperations();
				break;


			default:
				System.out.println("Invalid input. Please try again.");
			}
		}
	}

	// Order operations
	public static void OrderOperations() {
		while (true) {
			System.out.println("Press 1 to Add Order\n"
					+ "Press 2 to Retrieve All Orders\n"
					+ "Press 3 to Delete Order\n"
					+ "Press 4 to Go Back to Main Menu");

			int input = sc.nextInt();

			switch (input) {
			case 1:
				Order order = OrderInputs();
				Order savedOrder = orderService.createOrder(order);
				System.out.println("Order added successfully: " + savedOrder);
				break;

			case 2:
				List<Order> orders = orderService.getOrder();
				for (Order o : orders) {
					System.out.println(o);
				}
				break;

			case 3:
				System.out.println("Enter Order ID to delete:");
				Long orderIdToDelete = sc.nextLong();
				orderService.deleteOrder(orderIdToDelete);
				System.out.println("Order deleted successfully.");
				break;

			case 4:
				Main.mainOperations();
				break;

			default:
				System.out.println("Invalid input. Please try again.");
			}
		}
	}
}
