package Dao;
import java.util.List;
import Entity.Employee;

public interface EmployeeDao {
	Employee createEmployee(Employee emp);	
	Employee getEmployeeByID(Long emp_id);
	//Employee updateEmployee(Long emp_id);
	Employee deleteEmployee(Long emp_id);
	List<Employee> getAllEmployees();
	Employee updateEmployee(Employee emp);
}
