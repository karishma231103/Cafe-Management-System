package Dao;
import java.util.List;
import Entity.Food;

public interface FoodDao {
	Food createFood(Food food);
	Food updateFood(Food foodToUpdate);
	Food deleteFood(Long food_id);
	List<Food>getAllFoods();
	Food getFoodById(Long food_id);
}

