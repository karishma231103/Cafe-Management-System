package Dao;
import java.util.List;
import Entity.User;

public interface UserDao {
	User createUser(User user);
	User getUserById(Long user_id);
	List<User> getAllUsers();
	User updateUser(User userToUpdate);
	String deleteUser(Long user_id);
}
