package Dao;

import java.util.List;
import Entity.Admin;
import Entity.Employee;

public interface AdminDao {
	Admin createAdmin(Admin admin);	
	Admin getAdmin(Long admin_id);
	List<Admin> getAllAdmins( );
}



