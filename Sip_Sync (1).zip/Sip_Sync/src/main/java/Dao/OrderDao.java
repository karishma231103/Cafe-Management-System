package Dao;

import java.util.List;

import Entity.Order;

public interface OrderDao {

	Order createOrder(Order order);	
	List getOrder();
	Order deleteOrder(Long order_id);
}
