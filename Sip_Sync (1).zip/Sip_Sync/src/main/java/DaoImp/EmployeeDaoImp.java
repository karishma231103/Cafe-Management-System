package DaoImp;

import Entity.Employee;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Dao.EmployeeDao;

import java.util.List;

public class EmployeeDaoImp implements EmployeeDao {
    
    private Session session;

    public EmployeeDaoImp(Session session) {
        this.session = session;
    }

    public EmployeeDaoImp() {
		// TODO Auto-generated constructor stub
	}

	@Override
    public Employee createEmployee(Employee emp) {
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            session.save(emp);
            transaction.commit();
            return emp;
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Employee getEmployeeByID(Long emp_id) {
        return session.get(Employee.class, emp_id);
    }

    

    @Override
    public Employee deleteEmployee(Long emp_id) {
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            Employee employee = session.get(Employee.class, emp_id);
            if (employee != null) {
                session.delete(employee);
                transaction.commit();
                return employee;
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Employee> getAllEmployees() {
        Query<Employee> query = session.createQuery("FROM Employee", Employee.class);
        return query.list();
    }

    @Override
    public Employee updateEmployee(Employee emp) {
    	Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            // Retrieve the existing employee
            Employee existingEmployee = session.get(Employee.class, emp.getEmp_Id());
            if (existingEmployee != null) {
                // Update fields
                existingEmployee.setEmp_Name(emp.getEmp_Name());
                existingEmployee.setEmp_position(emp.getEmp_position());
                existingEmployee.setSalary(emp.getSalary());
                // Save the changes
                session.update(existingEmployee);
                transaction.commit();
                return existingEmployee;
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
        return null;
    }
}
