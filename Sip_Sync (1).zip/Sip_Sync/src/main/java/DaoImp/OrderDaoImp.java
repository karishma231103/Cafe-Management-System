package DaoImp;

import java.util.List;

import org.hibernate.Session;

import org.hibernate.Transaction;
import org.hibernate.query.Query;

import Dao.OrderDao;
import Entity.Employee;
import Entity.Food;
import Entity.Order;
import Entity.User;
import UtilFile.hibernateUtil;

public class OrderDaoImp implements OrderDao{

	@Override
	public Order createOrder(Order order) {
		Transaction transaction = null;
		try(Session session=hibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			session.save(order);
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) transaction.rollback();
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Entity.Order> getOrder() {
		try(Session session=hibernateUtil.getSessionFactory().openSession()) {
			Query<Order> query = session.createQuery("from orders", Order.class);
			return query.list();
		}
	}
	@Override
	public Order deleteOrder(Long order_id) {
		Transaction transaction = null;
		try (Session session = hibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			Order order = session.get(Order.class, order_id);
			if (order != null) {
				session.delete(order);
			}
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) transaction.rollback();
			e.printStackTrace();
		}
		return null;
	}

}

