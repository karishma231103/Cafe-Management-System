package DaoImp;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import Dao.UserDao;
import Entity.User;
import UtilFile.hibernateUtil;

public class UserDaoImp implements UserDao{

	@Override
	public User createUser(User user) {
		Transaction transaction = null;
		try(Session session=hibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			session.save(user);
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) transaction.rollback();
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public User getUserById(Long user_id) {
		try (Session session = hibernateUtil.getSessionFactory().openSession()) {
			return session.get(User.class, user_id);
		}
	}

	@Override
	public List<User> getAllUsers() {
		try (Session session = hibernateUtil.getSessionFactory().openSession()) {
			Query<User> query = session.createQuery("from Employees", User.class);
			return query.list();
		}	}

	@Override
    public User updateUser(User userToUpdate) {
        Transaction transaction = null;
        try (Session session = hibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            // Check if the user entity exists
            User existingUser = session.get(User.class, userToUpdate.getUser_id());
            if (existingUser != null) {
                // Update fields
                existingUser.setName(userToUpdate.getName());
                existingUser.setPhone_no(userToUpdate.getPhone_no());
                existingUser.setPassword(userToUpdate.getPassword());
                // Save the changes
                session.update(existingUser);
                transaction.commit();
                return existingUser;
            } else {
                System.out.println("User not found with id: " + userToUpdate.getUser_id());
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
        return null;
    }

	  @Override
	    public String deleteUser(Long user_id) {
	        Transaction transaction = null;
	        try (Session session = hibernateUtil.getSessionFactory().openSession()) {
	            transaction = session.beginTransaction();
	            User user = session.get(User.class, user_id);
	            if (user != null) {
	                session.delete(user);
	                transaction.commit();
	                return "User deleted successfully";
	            } else {
	                System.out.println("User not found with id: " + user_id);
	            }
	        } catch (Exception e) {
	            if (transaction != null) transaction.rollback();
	            e.printStackTrace();
	        }
	        return "User deletion failed";
	    }
}
