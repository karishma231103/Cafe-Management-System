package DaoImp;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import UtilFile.hibernateUtil;
import Dao.AdminDao;
import Entity.Admin;

public class AdminDaoImp implements AdminDao {

    @Override
    public Admin createAdmin(Admin admin) {
        Transaction transaction = null;
        try (Session session = hibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(admin);
            transaction.commit();
            return admin;
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.out.println(e);
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            System.out.println(e);
        }
        return null;
    }

    @Override
    public Admin getAdmin(Long admin_id) {
        try (Session session = hibernateUtil.getSessionFactory().openSession()) {
            Admin admin = session.get(Admin.class, admin_id);
            return admin;
        } catch (HibernateException e) {
            System.out.println(e);
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    @Override
    public List<Admin> getAllAdmins() {
        try (Session session = hibernateUtil.getSessionFactory().openSession()) {
            // Execute HQL query to retrieve all Admins data
            Query<Admin> query = session.createQuery("FROM Admin", Admin.class);
            List<Admin> adminList = query.list();
            return adminList;
        } catch (HibernateException e) {
            System.out.println(e);
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
}
