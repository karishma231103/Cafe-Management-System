package DaoImp;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import Dao.FoodDao;
import Entity.Food;
import UtilFile.hibernateUtil;

public class FoodDaoImp implements FoodDao {

    @Override
    public Food createFood(Food food) {
        Transaction transaction = null;
        try (Session session = hibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(food);
            transaction.commit();
            return food;
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Food updateFood(Food foodToUpdate) {
        Transaction transaction = null;
        try (Session session = hibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            // Check if the food entity exists
            Food existingFood = session.get(Food.class, foodToUpdate.getFood_id());
            if (existingFood != null) {
                // Update fields
                existingFood.setName(foodToUpdate.getName());
                existingFood.setPrice(foodToUpdate.getPrice());
                existingFood.setAvailability(foodToUpdate.getAvailability());
                // Save the changes
                session.update(existingFood);
                transaction.commit();
                return existingFood;
            } else {
                System.out.println("Food not found with id: " + foodToUpdate.getFood_id());
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public Food deleteFood(Long food_id) {
        Transaction transaction = null;
        try (Session session = hibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Food food = session.get(Food.class, food_id);
            if (food != null) {
                session.delete(food);
                transaction.commit();
                return food;
            } else {
                System.out.println("Food not found with id: " + food_id);
                if (transaction != null) transaction.rollback();
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public Food getFoodById(Long food_id) {
        try (Session session = hibernateUtil.getSessionFactory().openSession()) {
            return session.get(Food.class, food_id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Food> getAllFoods() {
        try (Session session = hibernateUtil.getSessionFactory().openSession()) {
            Query<Food> query = session.createQuery("FROM Food", Food.class);
            return query.list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
