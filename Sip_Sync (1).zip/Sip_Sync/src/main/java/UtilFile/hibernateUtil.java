package UtilFile;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;
import Entity.Admin;
import Entity.Employee;
import Entity.Food;
import Entity.Order;
import Entity.User;

public class hibernateUtil {

    private static SessionFactory sessionFactory;

    static {
        try {
            Configuration configuration = new Configuration();
            configuration.setProperty("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
            configuration.setProperty("hibernate.connection.driver_class", "com.mysql.cj.jdbc.Driver");
            configuration.setProperty("hibernate.connection.url", "jdbc:mysql://localhost:3306/cms");
            configuration.setProperty("hibernate.connection.username", "root");
            configuration.setProperty("hibernate.connection.password", "123456789");
            configuration.setProperty("hibernate.hbm2ddl.auto", "update");

            // Add annotated classes (Entities)
            configuration.addAnnotatedClass(Admin.class); 
            configuration.addAnnotatedClass(Employee.class);
            configuration.addAnnotatedClass(Food.class);
            configuration.addAnnotatedClass(Order.class);
            configuration.addAnnotatedClass(User.class);

            
            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties()).build();

            sessionFactory = configuration.buildSessionFactory(serviceRegistry);
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new ExceptionInInitializerError("Initial SessionFactory creation failed" + ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
