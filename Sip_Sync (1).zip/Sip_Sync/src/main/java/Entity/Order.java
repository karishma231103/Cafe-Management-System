package Entity;
import javax.persistence.*;

import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name = "Orders")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long order_id;
	private String total_amount;
	private LocalDate order_date;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User users;
	
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Order(String total_amount, LocalDate order_date, User users) {
		super();
		
		this.total_amount = total_amount;
		this.order_date = order_date;
		this.users = users;
	}


	// Getters and Setters
	public Long getOrder_id() {
		return order_id;
	}

	public void setOrder_id(Long order_id) {
		this.order_id = order_id;
	}

	public String getTotal_amount() {
		return total_amount;
	}

	public void setTotal_amount(String total_amount) {
		this.total_amount = total_amount;
	}

	public LocalDate getOrder_date() {
		return order_date;
	}

	public void setOrder_date(LocalDate order_date) {
		this.order_date = order_date;
	}

	public User getUsers() {
		return users;
	}

	public void setUsers(User users) {
		this.users = users;
	}
	@Override
	public String toString() {
		return "Order [Admin id=" + order_id + ", Total amount=" + total_amount + ", Order Date =" + order_date + "]";
	}
}