package Entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long emp_Id;
	@Column(length = 20)
	private String emp_Name;
	@Column(length = 20)
	private String emp_position; 
	@Column(length = 20)
	private String salary;
	//@Column(length = 20)

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee( String empName,String empPosition ,String salary) {
		super();
		
		this.emp_Name = empName;
		this.emp_position=empPosition;
		this.salary = salary;
	}
	public Long getEmp_Id() {
		return emp_Id;
	}
	public void setEmp_Id(Long emp_Id) {
		this.emp_Id = emp_Id;
	}
	public String getEmp_Name() {
		return emp_Name;
	}

	public void setEmp_Name(String emp_Name) {
		this.emp_Name = emp_Name;
	}
	public String getEmp_position() {
		return emp_position;
	}
	public void setEmp_position(String emp_position) {
		this.emp_position = emp_position;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + emp_Id + ", empName=" + emp_Name + ", salary=" + salary + "]";
	}
}
