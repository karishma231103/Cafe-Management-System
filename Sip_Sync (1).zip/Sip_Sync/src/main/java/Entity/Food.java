package Entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Foods")
public class Food {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long food_id;

	private String name;
	private String price;
	private String availability;
	public Long getFood_id() {
		return food_id;
	}
	public Food() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Food(  String name, String price,String availability) 
	{
		super();
		
		this.name = name;
		this.price = price;
		this.availability= availability;
	}
	// Getters and Setters

	public void setFood_id(Long food_id) {
		this.food_id = food_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	@Override
	public String toString() {
		return "Food [Food ID=" + food_id + ", Name=" + name + ", Price=" + price+ ", "
				+ "Availability=" + availability + "]";
	}
}