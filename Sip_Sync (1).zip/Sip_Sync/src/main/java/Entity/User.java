package Entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Users")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long user_id;
	private String name;
	private String phone_no;
	private String password;
	public Long getUser_id() {
		return user_id;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User( String name, String phone_no2,String password2) 
	{
		super();
	
		this.name = name;
		this.phone_no = phone_no2;
		this.password= password2;
	}
	
	public void setUser_id(Long user_id) {
		this.user_id = user_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "User [User id=" + user_id + ", Name=" + name + ", Phone No=" + phone_no + ", Password=" + password+ "]";
	}
}
