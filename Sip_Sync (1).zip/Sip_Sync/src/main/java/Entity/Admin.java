package Entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Admin")
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long admin_id;

	private String name;
	private String password;
	private String email;
	private String phone_no;
	public Long getAdmin_id() {
		return admin_id;
	}
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(  String name, String password,String email, String phone_no) 
	{
		super();
		
		this.name = name;
		this.password= password;
		this.email = email;
		this.phone_no = phone_no;
	}
	// Getters and Setters
	public void setAdmin_id(Long admin_id) {
		this.admin_id = admin_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	@Override
	public String toString() {
		return "Admin [Admin id=" + admin_id + ", Admin Name=" + name + ", Password=" + password+ ", "
				+ "Email=" + email+", Phone No=" + phone_no + "]";
	}
}