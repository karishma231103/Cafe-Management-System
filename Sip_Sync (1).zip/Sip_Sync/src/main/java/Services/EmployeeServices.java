package Services;
import java.util.List;
import Entity.Employee;

public interface EmployeeServices {
	Employee createEmployee(Employee emp);	
	Employee getEmployeeByID(Long emp_id);
	Employee deleteEmployee(Long emp_id);
	List<Employee> getAllEmployees();
	Employee updateEmployee(Employee employeeToUpdate);

}