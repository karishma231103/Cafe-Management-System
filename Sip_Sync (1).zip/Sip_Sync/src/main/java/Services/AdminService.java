package Services;

import java.util.List;
import Entity.Admin;

public interface AdminService {
	Admin createAdmin(Admin admin);	
	Admin getAdminById(Long admin_id);
	List<Admin> getAllAdmins();
}
