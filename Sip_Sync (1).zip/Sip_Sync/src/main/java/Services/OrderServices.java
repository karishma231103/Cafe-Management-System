package Services;
import java.util.List;
import Entity.Order;

public interface OrderServices {
	Order createOrder(Order orders);	
	List getOrder();
	Order deleteOrder(Long order_id);
}
