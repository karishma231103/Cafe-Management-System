package Services;

import java.util.List;
import Entity.User;

public interface UserServices {
	User createUser(User user);
	User getUserById(Long user_id);
	List<User> getAllUsers();
	String deleteUser(Long user_id);
	User updateUser(User userToUpdate);
}
