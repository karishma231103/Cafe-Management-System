package Services;

import java.util.List;
import Entity.Food;

public interface FoodServices {
	Food createFood(Food food);
	Food updateFood(Food foodToUpdate);
	Food deleteFood(Long food_id);
	Food getFoodById(Long food_id);
	List<Food>getAllFoods();
	
}
